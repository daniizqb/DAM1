SET SERVEROUTPUT ON
-- cursor para listar empleados con email empieza por letra
-- by Carlos Rossique
DECLARE
v_letra VARCHAR2(1);
cursor c_empleados(letra VARCHAR2) IS
SELECT first_name, last_name, job_title FROM EMPLOYEES INNER JOIN JOBS ON
employees.job_id=jobs.job_id WHERE SUBSTR(email,1,1)=letra;
r_empleados c_empleados%ROWTYPE; 
BEGIN
v_letra:=UPPER('&letra');
OPEN c_empleados(v_letra);
FETCH c_empleados INTO r_empleados;
    WHILE c_empleados%FOUND LOOP
        DBMS_OUTPUT.PUT_LINE(r_empleados.first_name
        ||' '||r_empleados.last_name||' '||r_empleados.job_title);
    FETCH c_empleados INTO r_empleados;    
    END LOOP;
CLOSE c_empleados;
END;