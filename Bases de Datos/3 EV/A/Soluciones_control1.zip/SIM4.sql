CREATE OR REPLACE FUNCTION CUBO(numero INTEGER) RETURN INTEGER
-- funci�n que devuelva el cubo de un numero <=1000
IS
e_grande EXCEPTION;
BEGIN
IF numero>1000 
    THEN RAISE e_grande;
END IF;
RETURN numero*numero*numero;
EXCEPTION
WHEN e_grande THEN
DBMS_OUTPUT.PUT_LINE ('El argumento es demasiado grande: ');
RETURN NULL;
END CUBO;
