CREATE OR REPLACE PROCEDURE LISTA_EMPLEADOS(ciudad VARCHAR2)
IS
CURSOR c_empleados IS
SELECT city, department_name, count(*) AS num FROM EMPLOYEES  
INNER JOIN DEPARTMENTS ON EMPLOYEES.department_id=departments.department_id
INNER JOIN LOCATIONS ON locations.location_id=departments.location_id
WHERE city = ciudad GROUP BY city, department_name;
BEGIN
FOR registro IN c_empleados
LOOP
DBMS_OUTPUT.PUT_LINE(registro.city||': '||registro.department_name
||' '||registro.num);
END LOOP;
END LISTA_EMPLEADOS;