SET SERVEROUTPUT ON
-- devolver apellido empleado m�s antiguo
DECLARE
v_ape EMPLOYEES.last_name%TYPE;
BEGIN
SELECT last_name INTO v_ape FROM (SELECT last_name FROM EMPLOYEES ORDER BY hire_date) WHERE ROWNUM=1; 
DBMS_OUTPUT.PUT_LINE ('El empleado m�s antiguo es '||v_ape);
END;