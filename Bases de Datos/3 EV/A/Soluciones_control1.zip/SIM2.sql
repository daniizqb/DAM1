SET SERVEROUTPUT ON
-- imprimir diversos datos de un departamento, con excepciones
DECLARE
v_id INTEGER; v_num INTEGER; v_idjefe INTEGER;
v_nombre VARCHAR2(100); v_jefe VARCHAR2(100);
e_no_emp EXCEPTION;
BEGIN
v_id:='&IDdepartamento';
SELECT department_name, manager_id INTO v_nombre, v_idjefe 
FROM DEPARTMENTS WHERE department_id = v_id; 
IF v_idjefe IS NOT NULL THEN
    SELECT last_name INTO v_jefe FROM EMPLOYEES WHERE employee_id=v_idjefe;
ELSE
    v_jefe:='NO TIENE JEFE';
END IF;
SELECT COUNT(*) INTO v_num FROM EMPLOYEES WHERE department_id = v_id;
IF v_num = 0 
    THEN RAISE e_no_emp;
END IF;
DBMS_OUTPUT.PUT_LINE('El departamento '||v_nombre||' tiene como jefe a '||v_jefe
||' y tiene '||v_num||' empleados');
EXCEPTION
WHEN NO_DATA_FOUND THEN 
    DBMS_OUTPUT.PUT_LINE ('No existe ese departamento');
WHEN e_no_emp THEN
    DBMS_OUTPUT.PUT_LINE('El departamento '||v_nombre||' tiene como jefe a '||v_jefe
||' y no tiene empleados');
WHEN OTHERS THEN 
    DBMS_OUTPUT.PUT_LINE ('Ha ocurrido un error inesperado');
END;