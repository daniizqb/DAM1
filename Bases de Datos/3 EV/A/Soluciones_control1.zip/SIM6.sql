CREATE OR REPLACE TRIGGER CAMBIO_EMPLEADOS 
BEFORE UPDATE OF job_id, department_id OR INSERT ON EMPLOYEES 
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        INSERT INTO CONTROL VALUES (:new.first_name, :new.last_name,
        'nuevo empleado',null,null); 
    ELSIF UPDATING('job_id') THEN
        INSERT INTO CONTROL VALUES (:new.first_name, :new.last_name,
        'nuevo trabajo',:old.job_id,:new.job_id);
    ELSIF UPDATING('department_id') THEN
        INSERT INTO CONTROL VALUES (:new.first_name, :new.last_name,
        'nuevo departamento',:old.department_id,:new.department_id);
    END IF;
END;