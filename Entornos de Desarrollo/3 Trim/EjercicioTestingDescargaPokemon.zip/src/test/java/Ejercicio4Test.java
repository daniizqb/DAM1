import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio4Test {

    static Ejercicio4 ej;

    @BeforeAll
    static void firstInit() {
        System.out.println("firstInit");
        ej = new Ejercicio4();
        ej.arrayPokemons = ObtenerPokemonsRequest.Companion.get(1,9);
    }

    @BeforeEach
    void setUp() {
        System.out.println("setUp");
    }

    @AfterEach
    void tearDown() {
        System.out.println("tearDown");
    }

    @Test
    void probarPokemonMasGordo() {
        Pokemon[] pokemonsEsperados = {
                new Pokemon(20, 3,"venusaur", 1000),
                new Pokemon(17, 6,"charizard", 905),
                new Pokemon(16, 9,"blastoise", 855)};
        Pokemon[] pokemonsActuales = ej.getPokemonMasGordo(250);
        Assertions.assertArrayEquals(pokemonsEsperados,pokemonsActuales);
    }

    @Test
    void probarPokemonMenosGordo() {
        Pokemon[] pokemonsEsperados = {
                new Pokemon(7, 1, "bulbasaur", 69),
                new Pokemon(10, 2, "ivysaur", 130),
                new Pokemon(6, 4, "charmander", 85),
                new Pokemon(11, 5, "charmeleon", 190),
                new Pokemon(5, 7, "squirtle", 90)};
        Pokemon[] pokemonsActuales = ej.getPokemonMenosGordo(225 );
        Assertions.assertArrayEquals(pokemonsEsperados,pokemonsActuales);
    }

    @Test
    void probarPokemonPesoEntre() {
        Pokemon[] pokemonsEsperados = {
                new Pokemon(10, 2, "ivysaur", 130),
                new Pokemon(11, 5, "charmeleon", 190),
                new Pokemon(10, 8, "wartortle", 225)};
        Pokemon[] pokemonsActuales = ej.getPokemonPesoEntre(250,100);
        Assertions.assertArrayEquals(pokemonsEsperados,pokemonsActuales);
    }

    @Test
    void probarPokemonNombreMasLargoQue() {
        Pokemon[] pokemonsEsperados = {
                new Pokemon(6, 4, "charmander", 85),
                new Pokemon(11, 5, "charmeleon", 190)};
        Pokemon[] pokemonsActuales = ej.getPokemonNombreMasLargoQue(9);
        Assertions.assertArrayEquals(pokemonsEsperados,pokemonsActuales);
    }

    @Test
    void probarPokemonNombreMasCortoQue() {
        Pokemon[] pokemonsEsperados = {new Pokemon(10, 2, "ivysaur", 130)};
        Pokemon[] pokemonsActuales = ej.getPokemonNombreMasLargoQue(9);
        Assertions.assertArrayEquals(pokemonsEsperados,pokemonsActuales);
    }

    @Test
    void getPokemonConLetras() {
        Pokemon[] pokemonsEsperados = {
                new Pokemon(7, 1,"bulbasaur", 69),
                new Pokemon(10, 2,"ivysaur", 130),
                new Pokemon(20, 3,"venusaur", 1000)};
        Pokemon[] pokemonsActuales = ej.getPokemonConLetras("saur");
        Assertions.assertArrayEquals(pokemonsEsperados,pokemonsActuales);
    }
}