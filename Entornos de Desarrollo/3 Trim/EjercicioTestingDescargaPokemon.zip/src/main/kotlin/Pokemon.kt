data class Pokemon (
    val height: Long,
    val id: Long,
    val name: String,
    val weight: Long
)