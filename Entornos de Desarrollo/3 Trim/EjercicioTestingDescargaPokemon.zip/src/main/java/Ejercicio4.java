import java.util.ArrayList;

public class Ejercicio4 {

    public Pokemon[] arrayPokemons = new Pokemon[0];

    public void iniciarEjercicio4() {
        System.out.println("Empezando el ej4");
        for (Pokemon pokemon : arrayPokemons) {
            System.out.println(pokemon);
        }

        System.out.println("getPokemonMasGordo");
        Pokemon[] result = getPokemonMasGordo(250);
        for (Pokemon pokemon : result) {
            System.out.println(pokemon);
        }

        System.out.println("getPokemonMenosGordo");
        result = getPokemonMenosGordo(225);
        for (Pokemon pokemon : result) {
            System.out.println(pokemon);
        }

        System.out.println("getPokemonPesoEntre");
        result = getPokemonPesoEntre(100,100);
        for (Pokemon pokemon : result) {
            System.out.println(pokemon);
        }

        System.out.println("getPokemonNombreMasLargoQue");
        result = getPokemonNombreMasLargoQue(9);
        for (Pokemon pokemon : result) {
            System.out.println(pokemon);
        }

        System.out.println("getPokemonNombreMasCortoQue");
        result = getPokemonNombreMasCortoQue(8);
        for (Pokemon pokemon : result) {
            System.out.println(pokemon);
        }

        System.out.println("getPokemonConLetras");
        result = getPokemonConLetras("saur");
        for (Pokemon pokemon : result) {
            System.out.println(pokemon);
        }
    }

    public ArrayList<Pokemon> pokemonsMasGordosQue(int peso) {
        ArrayList<Pokemon> out = new ArrayList<>();
        for (Pokemon pokemon : arrayPokemons) {
            if (pokemon.getWeight() > peso)
                out.add(pokemon);
        }

        return out;
    }

    public Pokemon[] getPokemonMasGordo(int peso) {
        Pokemon[] arrayPokemonsGordos = new Pokemon[arrayPokemons.length];
        int i = 0;

        for (Pokemon pokemon : arrayPokemons) {
            if (pokemon.getWeight() > peso) {
                arrayPokemonsGordos[i] = pokemon;
                i++;
            }
        }

        return getArraySinNulos(arrayPokemonsGordos,i);
    }

    public Pokemon[] getPokemonMenosGordo(int peso) {
        Pokemon[] arrayPokemonsGordos = new Pokemon[arrayPokemons.length];
        int i = 0;

        for (Pokemon pokemon : arrayPokemons) {
            if (pokemon.getWeight() < peso) {
                arrayPokemonsGordos[i] = pokemon;
                i++;
            }
        }

        return getArraySinNulos(arrayPokemonsGordos,i);
    }

    public Pokemon[] getPokemonPesoEntre(int pesoMaximo, int pesoMinimo) { // pesoMaximo y pesoMinimo no incluidos
        Pokemon[] arrayPokemonsGordos = new Pokemon[arrayPokemons.length];
        int i = 0;

        for (Pokemon pokemon : arrayPokemons) {
            if (pokemon.getWeight() > pesoMinimo && pokemon.getWeight() < pesoMaximo) {
                arrayPokemonsGordos[i] = pokemon;
                i++;
            }
        }

        return getArraySinNulos(arrayPokemonsGordos,i);
    }

    public Pokemon[] getPokemonNombreMasLargoQue(int longitud) {
        Pokemon[] arrayPokemonsLargos = new Pokemon[arrayPokemons.length];
        int i = 0;

        for (Pokemon pokemon : arrayPokemons) {
            if (pokemon.getName().length() > longitud) {
                arrayPokemonsLargos[i] = pokemon;
                i++;
            }
        }

        return getArraySinNulos(arrayPokemonsLargos,i);
    }

    public Pokemon[] getPokemonNombreMasCortoQue(int longitud) {
        // TODO
        Pokemon[] arrayPokemonsLargos = new Pokemon[arrayPokemons.length];
        int i = 0;

        for (Pokemon pokemon : arrayPokemons) {
            if (pokemon.getName().length() < longitud) {
                arrayPokemonsLargos[i] = pokemon;
                i++;
            }

        }

        return getArraySinNulos(arrayPokemonsLargos,i);
    }

    public Pokemon[] getPokemonConLetras(String letras)  {
        Pokemon[] arrayPokemonsLargos = new Pokemon[arrayPokemons.length];
        int i = 0;
        boolean f = true;
        for (Pokemon pokemon : arrayPokemons) {
            char[] aLetras = letras.toCharArray();
            for (char l:aLetras) {
                if (!pokemon.getName().contains(""+l)) {
                    f = false;
                    break;
                }
            }
            if (f) {
                arrayPokemonsLargos[i] = pokemon;
                i++;
            }

        }

        return getArraySinNulos(arrayPokemonsLargos,i);
    } // Atención, esta operación debe devolver un array de pokemons vacio si letras fuera null.

    public Pokemon[] getArraySinNulos(Pokemon[] aPok,int numPokemons) {
        Pokemon[] out = new Pokemon[numPokemons];
        System.arraycopy(aPok,0,out,0,numPokemons);

        return out;
    }

}
