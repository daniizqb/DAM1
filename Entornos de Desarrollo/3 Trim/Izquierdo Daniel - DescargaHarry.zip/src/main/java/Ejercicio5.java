import java.util.ArrayList;

public class Ejercicio5 {

    public Personajes personajes;

    public Ejercicio5() {
        personajes = new Personajes(ObtenerPersonajesRequest.Companion.get());
    }

    // TODO Haz una función que te devuelva un array compuesto por:
    //  Personajes que tienen imagen asociada.

    public Personaje[] getPersonajesConImagen() {
        Personaje[] output = new Personaje[personajes.obtenerTodos().length];
        short i = 0;

        for(Personaje p:personajes.obtenerTodos()) {
            if (!p.getImage().isEmpty()) {
                output[i] = p;
                i++;
            }
        }
        return output;
    }

    public short getNumeroDePersonajesConImagen() {
        short i = 0;

        for(Personaje p:personajes.obtenerTodos()) {
            if (!p.getImage().isEmpty()) {
                i++;
            }
        }
        return i;
    }

    public short getMiembrosStaffVivos() {
        short i = 0;

        for(Personaje p:personajes.obtenerTodos()) {
            if (p.getHogwartsStaff() && p.getAlive()) {
                i++;
            }
        }
        return i;
    }

    public short getMiembrosStaffMuertos() {
        short i = 0;

        for(Personaje p:personajes.obtenerTodos()) {
            if (p.getHogwartsStaff() && !p.getAlive()) {
                i++;
            }
        }
        return i;
    }

    public short getPersonajesConLetra(char letra) {
        short i = 0;

        for(Personaje p:personajes.obtenerTodos()) {
            if (p.getName().contains(Character.toString(letra))) {
                i++;
            }
        }
        return i;
    }

    public short getPersonajesConStringVivos(String str) {
        short i = 0;

        for(Personaje p:personajes.obtenerTodos()) {
            if (p.getName().contains(str) && p.getAlive()) {
                i++;
            }
        }
        return i;
    }

    public ArrayList<Personaje> getPersonajesConNombreIgualAString(String str) {
        ArrayList<Personaje> list = new ArrayList<>();

        for(Personaje p:personajes.obtenerTodos()) {
            if (p.getName().equals(str)) {
                list.add(p);
            }
        }

        return list;
    }

}
