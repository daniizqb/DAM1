data class Personaje (
    val name: String,
    val wizard: Boolean,
    val hogwartsStudent: Boolean,
    val hogwartsStaff: Boolean,
    val actor: String,
    val alive: Boolean,
    val image: String
)