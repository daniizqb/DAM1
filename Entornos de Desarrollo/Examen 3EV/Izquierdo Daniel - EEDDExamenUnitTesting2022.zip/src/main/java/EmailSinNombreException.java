public class EmailSinNombreException extends Exception {
}
