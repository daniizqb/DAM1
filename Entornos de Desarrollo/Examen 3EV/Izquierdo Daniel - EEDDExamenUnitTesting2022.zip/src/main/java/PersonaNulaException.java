public class PersonaNulaException extends Exception {
}
