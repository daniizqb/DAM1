import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class PersonajeTest {


    Examen examen = new Examen();

    // TIP:
    // Para obtener la lista de personas:
    //      examen.personas.getResults()
    // Para obtener una persona:
    //      examen.personas.getResults()[0]

    @Test
    public void testObtenerMujeres() {
        Persona[] p = {examen.gestorDePersonas.getPersonas()[4], examen.gestorDePersonas.getPersonas()[5], examen.gestorDePersonas.getPersonas()[6], examen.gestorDePersonas.getPersonas()[8], examen.gestorDePersonas.getPersonas()[9]};
        Assertions.assertEquals(p, examen.obtenerMujeres());
    }

    @Test
    public void testObtenerHombres_01() {
        Persona[] p = {examen.gestorDePersonas.getPersonas()[0], examen.gestorDePersonas.getPersonas()[1], examen.gestorDePersonas.getPersonas()[2], examen.gestorDePersonas.getPersonas()[3], examen.gestorDePersonas.getPersonas()[7]};
        try {
            Assertions.assertEquals(p, examen.obtenerHombres(p));
        } catch (PersonaNulaException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Error");
        }
    }

    @Test
    public void testObtenerHombres_02() {
        Persona[] p = {null, null};

        Assertions.assertThrows(PersonaNulaException.class, () -> examen.obtenerHombres(p));
    }

    @Test
    public void testObtenerPersonasCuyoTelefonoContiene_01() {
        Assertions.assertEquals(9, examen.obtenerPersonasCuyoTelefonoContiene("6").length);
    }

    @Test
    public void testObtenerPersonasCuyoTelefonoContiene_02() {
        Assertions.assertThrows(NullPointerException.class, () -> examen.obtenerPersonasCuyoTelefonoContiene(null));
    }

    @Test
    public void testComprobarEmailEmpiezaPorNombre_01() {
        Assertions.assertThrows(PersonaNulaException.class, () -> examen.comprobarEmailEmpiezaPorNombre(null));
    }

    @Test
    public void testComprobarEmailEmpiezaPorNombre_02() {
        Assertions.assertThrows(EmailSinNombreException.class, () -> examen.comprobarEmailEmpiezaPorNombre(examen.gestorDePersonas.getPersonas()[1]));
    }

    @Test
    public void testVerificarTitulos() {
        Persona[] p = {examen.gestorDePersonas.getPersonas()[5], examen.gestorDePersonas.getPersonas()[8]};

        try {
            Assertions.assertTrue(examen.verificarTitulos(p));
        } catch (PersonaNulaException | NullPointerException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Error");
        }
    }

    @Test
    public void testVerificarTitulos_02() {
        Assertions.assertThrows(NullPointerException.class, () -> examen.verificarTitulos(null));
    }

    @Test
    public void testVerificarTitulos_03() {
        Persona[] p = {examen.gestorDePersonas.getPersonas()[1], null};
        Assertions.assertThrows(PersonaNulaException.class, () -> examen.verificarTitulos(p));
    }

    // TODO: (2,5 puntos) Piensa en que test son necesarios para probar la función "passSegura" y realizalos.
    //  Si la persona es null deberá devolver la excepción PersonaNulaException
    //  Si la contraseña es null o está vacía deberá devolver la excepción PassInvalidaException
    //  Si la contraseña cumple todas estas condiciones:
    //  - Longitud 8 y 16 caracteres
    //  - Al menos un dígito
    //  - Al menos una minúscula
    //  - Al menos una mayúscula.
    //  - NO puede tener otros símbolos.
    //  passSegura deberá devolver "true". En caso contrario, "false"
    @Test
    public void testPassSegura_01() {
        // Tip:
        // Ejemplo de llamada a la funcion esEspanol
        // PersonasFun.Companion.esPassValida(examen.personas.getResults()[0]);
        Assertions.assertThrows(PersonaNulaException.class, () -> PersonasFun.Companion.passSegura(null));
    }

    @Test
    public void testPassSegura_02() {
        Persona p = examen.gestorDePersonas.getPersonas()[0];
        //Probado con la contraseña del usuario 0: null
        Assertions.assertThrows(PassInvalidaException.class, () -> PersonasFun.Companion.passSegura(p));
    }

    @Test
    public void testPassSegura_03() {
        // Sin digito ni mayus ni longitud
        Assertions.assertFalse(PersonasFun.Companion.passSegura(examen.gestorDePersonas.getPersonas()[0]));
    }

    @Test
    public void testPassSegura_04() {
        // Sin mayus ni longitud
        Assertions.assertFalse(PersonasFun.Companion.passSegura(examen.gestorDePersonas.getPersonas()[1]));
    }

    @Test
    public void testPassSegura_05() {
        // Pass correcta
        Persona p = examen.gestorDePersonas.getPersonas()[0];
        //Probado con la contraseña del usuario 0: "aNdada12"
        Assertions.assertTrue(PersonasFun.Companion.passSegura(p));
    }

    @Test
    public void testPassSegura_06() {
        // Sin minus
        Persona p = examen.gestorDePersonas.getPersonas()[0];
        //Probado con la contraseña del usuario 0: "MDADMADA"
        Assertions.assertTrue(PersonasFun.Companion.passSegura(p));
    }

    @Test
    public void testPassSegura_07() {
        // Con simbolos
        Persona p = examen.gestorDePersonas.getPersonas()[0];
        //Probado con la contraseña del usuario 0: "adadM141$"
        Assertions.assertTrue(PersonasFun.Companion.passSegura(p));
    }

    // TODO: (2,5 puntos) Piensa en que test son necesarios para probar la función "esEspanol" y realizalos.
    //  Esta función mira si el documento de identidad de la persona es un "DNI". No debe tener en cuenta las mayúsculas.
    //  Es decir, ya ponga "DNI", "dni", "Dni", etc, se debería considerar español y por tanto devolver true.
    //  Si la persona recibida es null, entonces devolverá PersonaNulaException
    //  Si cumple la condición anterior pero el "value" del documento de identidad es null, entonces devolverá un
    //  DocumentoInvalidoException
    @Test
    public void testEsEspanol_01() {
        // Tip:
        // Ejemplo de llamada a la funcion esEspanol
        // PersonasFun.Companion.esEspanol(examen.personas.getResults()[0]);
        Persona p = examen.gestorDePersonas.getPersonas()[4];
        Assertions.assertTrue(PersonasFun.Companion.esEspanol(p));
    }

    @Test
    public void testEsEspanol_02() {
        Persona p = examen.gestorDePersonas.getPersonas()[7];
        Assertions.assertTrue(PersonasFun.Companion.esEspanol(p));
    }

    @Test
    public void testEsEspanol_03() {
        Assertions.assertThrows(PersonaNulaException.class, () -> PersonasFun.Companion.esEspanol(null));
    }

    @Test
    public void testEsEspanol_04() {
        Persona p = examen.gestorDePersonas.getPersonas()[7];
        Assertions.assertThrows(DocumentoInvalidoException.class, () -> PersonasFun.Companion.esEspanol(p));
    }

}
