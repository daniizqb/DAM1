public class Main {
    public static void main(String[] args) {
        System.out.println("Bienbenidos al examen de DAM 1");
        System.out.println("Git pertenece al Tema 3: Herramientas de desarrollo.");
        System.out.println("Ahora descubriremos si sabes usarlo.");
        System.out.println("Y esto es todo...");
    }
}
