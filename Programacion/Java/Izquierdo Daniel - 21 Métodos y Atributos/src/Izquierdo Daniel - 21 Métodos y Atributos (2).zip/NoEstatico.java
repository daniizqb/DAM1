public class NoEstatico {
    public void mensajeEdad(Persona p) {
        System.out.printf("%s mayor de edad\n",p.esMayorDeEdad() ? "Es" : "No");
    }
}
