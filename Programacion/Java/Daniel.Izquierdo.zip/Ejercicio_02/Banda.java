public class Banda
{
    private Musico[] musicos = new Musico[4];
    
    public Banda(Musico[] musicos) {
        this.musicos = musicos;
    }


    public Musico[] getMusicos() {
        return musicos;
    }
}
